# config/initializers/turbo.rb
Turbo::Streams::TagBuilder.prepend(Module.new do
  def turbo_stream_from(*streamables, **options)
    tag.turbo_cable_stream_source(
      channel: "Turbo::StreamsChannel",
      signed_stream_name: Turbo::StreamsChannel.signed_stream_name(streamables),
      **options
    )
  end
end)