# config/routes.rb
Rails.application.routes.draw do
    # Dashboard routes
  get 'dashboard', to: 'dashboard#index'
  get 'dashboard/index'
  get 'dashboard/refresh_news'  # Cambiado a GET para simplificar
  get 'dashboard/refresh_weather' # Cambiado a GET para simplificar
  get "home/index"
  devise_for :users, controllers: {
    registrations: 'registrations'
  }
  
  root 'home#index'
  get 'dashboard', to: 'dashboard#index'

  resources :categories
  resources :products do
    member do
      delete :delete_image
    end
  end

  mount ActionCable.server => '/cable'
end