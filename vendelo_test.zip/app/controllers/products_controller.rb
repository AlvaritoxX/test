class ProductsController < ApplicationController
  before_action :set_product, only: %i[show edit update destroy]

def index
  @q = Product.ransack(params[:q])
  @products = @q.result.includes(:category).order(created_at: :desc)
  @categories = Category.all

  respond_to do |format|
    format.html
    format.turbo_stream
  end
end

  def show
  end

  def new
    @product = Product.new
  end

  def create
    @product = Product.new(product_params)
    if @product.save
      redirect_to @product, notice: "Producto creado correctamente."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
    
  end

  def update
    
    if @product.update(product_params)
      @product.broadcast  # Llamada manual al broadcast
      redirect_to @product, notice: "Producto actualizado correctamente."
    else
      render :edit, status: :unprocessable_entity
    end
  end


def destroy
  @product = Product.find(params[:id])
  @product.destroy
  
  
  @q = Product.ransack(params[:q])
  @products = @q.result.includes(:category).order(created_at: :desc)
  @categories = Category.all
  
  respond_to do |format|
    format.html { 
      redirect_to products_path, 
      notice: "Producto eliminado correctamente." 
    }
    format.turbo_stream { 
      render turbo_stream: [
        turbo_stream.replace("products-table", 
          partial: "products/products_table", 
          locals: { products: @products, q: @q }
        ),
        turbo_stream.update("flash", 
          partial: "shared/flash", 
          locals: { notice: "Producto eliminado correctamente." }
        )
      ]
    }
  end
end

  private

  def set_product
    @product = Product.find(params[:id])
  end

 def product_params
  params.require(:product).permit(:name, :description, :price, :category_id, :image)
end
end