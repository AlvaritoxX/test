# app/controllers/categories_controller.rb
class CategoriesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_category, only: [:show, :edit, :update, :destroy]

  def index
    @categories = Category.all
  end

  def show
  end

  def new
    @category = Category.new
  end

  def create
    service = Categories::CreateService.new(category_params)
    result = service.call

    if result[:success]
      redirect_to categories_path, notice: 'Categoría creada exitosamente.'
    else
      @category = Category.new(category_params)
      flash[:alert] = result[:errors].join(', ')
      render :new
    end
  end

  def edit
  end

  def update
    service = Categories::UpdateService.new(@category, category_params)
    result = service.call

    if result[:success]
      redirect_to categories_path, notice: 'Categoría actualizada exitosamente.'
    else
      flash[:alert] = result[:errors].join(', ')
      render :edit
    end
  end

  def destroy
    @category.destroy
    redirect_to categories_path, notice: 'Categoría eliminada exitosamente.'
  end

  private

  def set_category
    @category = Category.find(params[:id])
  end

  def category_params
    params.require(:category).permit(:name, :description)
  end
end