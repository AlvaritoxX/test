# app/controllers/registrations_controller.rb
class RegistrationsController < Devise::RegistrationsController
  def create
    service = Users::RegistrationService.new(sign_up_params)
    result = service.call

    if result[:success]
      set_flash_message! :notice, :signed_up
      sign_up(resource_name, result[:user])
      respond_with result[:user], location: after_sign_up_path_for(result[:user])
    else
      clean_up_passwords result[:user]
      set_minimum_password_length
      respond_with result[:user]
    end
  end

  private

  def sign_up_params
    params.require(:user).permit(:email, :password, :password_confirmation)
  end
end