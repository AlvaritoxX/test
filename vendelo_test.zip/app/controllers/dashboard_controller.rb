class DashboardController < ApplicationController
  def index
    begin
      @news = NewsService.fetch_news
      @weather = WeatherService.fetch_weather
      
      @news_error = @news.blank?
      @weather_error = @weather.blank?
      
    rescue StandardError => e
      Rails.logger.error "Dashboard error: #{e.message}"
      @news = NewsService.sample_news
      @weather = WeatherService.sample_weather
      @news_error = true
      @weather_error = true
    end
  end
  
  def refresh_news
    @news = NewsService.fetch_news
    redirect_to dashboard_index_path, notice: 'Noticias actualizadas'
  end
  
  def refresh_weather
    @weather = WeatherService.fetch_weather
    redirect_to dashboard_index_path, notice: 'Clima actualizado'
  end
end