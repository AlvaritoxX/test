# app/models/product.rb
class Product < ApplicationRecord
  belongs_to :category
  
  validates :name, presence: true
  validates :price, presence: true, numericality: { greater_than: 0 }
  validates :description, presence: true

  # Active Storage para imágenes
  has_one_attached :image
  
  # Validaciones
  validate :acceptable_image
  
  # Optimizar imagen después de adjuntarla
  after_save :optimize_image, if: :image_attached?

  def broadcast
    broadcast_replace_to(
      self,
      target: "product_#{id}",
      partial: "products/product_details",
      locals: { product: self }
    )
  end

  # Configuración de Ransack para seguridad
  def self.ransackable_attributes(auth_object = nil)
    # Solo permitir búsqueda en estos atributos (excluir información sensible)
    %w[name description price category_id created_at updated_at]
  end

  def self.ransackable_associations(auth_object = nil)
    # Permitir búsqueda a través de estas asociaciones
    %w[category]
  end

  # Opcional: Métodos personalizados para Ransack
  def self.ransackable_scopes(auth_object = nil)
    [] # Puedes agregar scopes personalizados aquí si los necesitas
  end

  private
  
  def acceptable_image
    return unless image.attached?
    
    # Validar tipo de archivo
    acceptable_types = ["image/jpeg", "image/png", "image/gif", "image/webp"]
    unless acceptable_types.include?(image.content_type)
      errors.add(:image, "debe ser JPEG, PNG, GIF o WebP")
    end
    
    # Validar tamaño (max 5MB)
    max_size = 5.megabytes
    if image.byte_size > max_size
      errors.add(:image, "debe ser menor a 5MB")
    end
  end
  
  def image_attached?
    image.attached?
  end
  
  def optimize_image
    return unless image.attached?
    
    # Optimizar la imagen en segundo plano
    ImageOptimizerJob.perform_later(self.id)
  end

  
end