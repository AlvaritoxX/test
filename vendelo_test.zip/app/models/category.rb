# app/models/category.rb
class Category < ApplicationRecord
  has_many :products, dependent: :destroy
  
  validates :name, presence: true, uniqueness: true
  validates :description, presence: true
  
  scope :active, -> { where(active: true) }


    # Configuración de Ransack para Category
  def self.ransackable_attributes(auth_object = nil)
    %w[name description created_at updated_at]
  end

  def self.ransackable_associations(auth_object = nil)
    %w[products]
  end
end