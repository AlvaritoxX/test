import { Controller } from "@hotwired/stimulus";
import { createConsumer } from "@rails/actioncable";



export default class extends Controller {
  static values = { productId: Number };        
    connect() {
        createConsumer().subscriptions.create({channel: "ProductChannel", room: this.productIdValue})
    }
  
}   