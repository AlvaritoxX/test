// app/javascript/controllers/form_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  static targets = ["submit"]

  connect() {
    this.validate()
  }

  validate() {
    const inputs = this.element.querySelectorAll('input[required], select[required]')
    let allValid = true

    inputs.forEach(input => {
      if (!input.value.trim()) {
        allValid = false
        input.classList.add('is-invalid')
      } else {
        input.classList.remove('is-invalid')
        input.classList.add('is-valid')
      }
    })

    if (this.hasSubmitTarget) {
      this.submitTarget.disabled = !allValid
    }
  }
}