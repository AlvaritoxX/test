// app/javascript/controllers/turbo_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  connect() {
    this.setupTurboNotifications()
  }

  setupTurboNotifications() {
    // Auto-ocultar flash messages después de 5 segundos
    document.addEventListener('turbo:load', () => {
      const flashMessages = document.getElementById('flash-messages')
      if (flashMessages) {
        setTimeout(() => {
          flashMessages.style.opacity = '0'
          setTimeout(() => flashMessages.remove(), 300)
        }, 5000)
      }
    })
  }
}