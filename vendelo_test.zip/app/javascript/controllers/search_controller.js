// app/javascript/controllers/search_controller.js
import { Controller } from "@hotwired/stimulus"

export default class extends Controller {
  initialize() {
    this.timeout = null
    this.initialized = false
    console.log('SearchController conectado')
  }

  connect() {
    // Pequeño delay para evitar envío automático al cargar
    setTimeout(() => {
      this.initialized = true
    }, 100)
  }

  search(event) {
    if (!this.initialized) return
    
    console.log('Buscando:', event.target.value)
    clearTimeout(this.timeout)
    
    this.timeout = setTimeout(() => {
      this.submitForm()
    }, 200)
  }

  filter(event) {
    if (!this.initialized) return
    
    console.log('Cambiando filtro:', event.target.name, event.target.value)
    this.submitForm()
  }

  submitForm() {
    console.log(' Enviando formulario...')
    this.element.requestSubmit()
  }

  disconnect() {
    clearTimeout(this.timeout)
  }
}