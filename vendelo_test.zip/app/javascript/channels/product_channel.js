// app/javascript/channels/product_channel.js
import consumer from "./consumer"

consumer.subscriptions.create("ProductChannel", {
  connected() {
    console.log("✅ Conectado al ProductChannel")
  },

  disconnected() {
    console.log("❌ Desconectado del ProductChannel")
  },

  received(data) {
    console.log("📡 Mensaje recibido del ProductChannel:", data)
  }
})