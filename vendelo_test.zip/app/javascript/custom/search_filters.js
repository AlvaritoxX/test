// app/javascript/custom/search_filters.js
function initializeSearchFilters() {
  const searchForm = document.getElementById('search-form');
  let timeoutId;

  if (searchForm) {
    console.log('🔍 Inicializando filtros de búsqueda...');

    // Campo de búsqueda con debounce
    const searchField = searchForm.querySelector('input[type="search"]');
    if (searchField) {
      searchField.addEventListener('input', function(e) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          console.log('🔄 Buscando:', this.value);
          searchForm.requestSubmit();
        }, 500);
      });
    }

    // Select de categoría - cambio inmediato
    const categorySelect = searchForm.querySelector('select[name*="category_id"]');
    if (categorySelect) {
      categorySelect.addEventListener('change', function() {
        console.log('🔄 Cambiando categoría:', this.value);
        searchForm.requestSubmit();
      });
    }

    // Campos de precio - cambio inmediato
    const priceFields = searchForm.querySelectorAll('input[type="number"]');
    priceFields.forEach(field => {
      field.addEventListener('change', function() {
        console.log('🔄 Cambiando precio:', this.name, this.value);
        searchForm.requestSubmit();
      });
    });

    // Agregar indicador de carga
    searchForm.addEventListener('submit', function() {
      showLoadingIndicator();
    });
  }
}

function showLoadingIndicator() {
  // Crear o mostrar indicador de carga
  let loader = document.getElementById('search-loading');
  if (!loader) {
    loader = document.createElement('div');
    loader.id = 'search-loading';
    loader.className = 'position-fixed top-0 start-50 translate-middle-x mt-3';
    loader.innerHTML = `
      <div class="alert alert-info shadow d-flex align-items-center">
        <div class="spinner-border spinner-border-sm me-2" role="status">
          <span class="visually-hidden">Cargando...</span>
        </div>
        Buscando productos...
      </div>
    `;
    document.body.appendChild(loader);
  }
  loader.style.display = 'block';

  // Ocultar después de 3 segundos (por si hay error)
  setTimeout(() => {
    hideLoadingIndicator();
  }, 3000);
}

function hideLoadingIndicator() {
  const loader = document.getElementById('search-loading');
  if (loader) {
    loader.style.display = 'none';
  }
}

// Ocultar loading cuando Turbo termine de cargar
document.addEventListener('turbo:frame-load', hideLoadingIndicator);
document.addEventListener('turbo:fetch-request-error', hideLoadingIndicator);

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', initializeSearchFilters);
// Y también cuando Turbo cargue una nueva página
document.addEventListener('turbo:load', initializeSearchFilters);