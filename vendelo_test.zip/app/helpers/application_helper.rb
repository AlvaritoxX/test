# app/helpers/application_helper.rb
module ApplicationHelper
  def bootstrap_alert_class(flash_type)
    case flash_type.to_sym
    when :notice, :success then 'success'
    when :alert, :error, :danger then 'danger'
    when :warning then 'warning'
    else 'info'
    end
  end
end