# app/helpers/products_helper.rb
module ProductsHelper
  def product_image_tag(product, variant: :medium, **options)
    if product.image.attached?
      case variant
      when :thumb
        image_tag product.image.variant(resize_to_fill: [100, 100]), **options
      when :medium
        image_tag product.image.variant(resize_to_limit: [400, 300]), **options
      when :large
        image_tag product.image.variant(resize_to_limit: [800, 600]), **options
      else
        image_tag product.image, **options
      end
    else
      image_tag 'placeholder-product.png', **options
    end
  end
end