# app/services/products/update_service.rb
module Products
  class UpdateService
    def initialize(product, product_params)
      @product = product
      @product_params = product_params
    end

    def call
      if @product.update(@product_params)
        { success: true, product: @product }
      else
        { success: false, errors: @product.errors.full_messages }
      end
    end
  end
end