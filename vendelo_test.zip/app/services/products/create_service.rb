# app/services/products/create_service.rb
module Products
  class CreateService
    def initialize(product_params)
      @product_params = product_params
    end

    def call
      product = Product.new(@product_params)
      
      if product.save
        { success: true, product: product }
      else
        { success: false, errors: product.errors.full_messages }
      end
    end
  end
end