class NewsService
  def self.fetch_news
    api_key = ENV["NEWS_API_KEY"]
    base_url = "https://newsapi.org/v2/top-headlines"
    country = "us"
    page_size = "5"

    # Si no hay API key, usar datos de ejemplo
    unless api_key.present? && api_key != "tu_key_real_o_demo"
      puts "=== Using demo news data ==="
      return sample_news
    end

    url = "#{base_url}?country=#{country}&pageSize=#{page_size}&apiKey=#{api_key}"
    
    begin
      response = HTTParty.get(url)
      puts "=== News API Response: #{response.code} ==="
      
      if response.success?
        articles = parse_news_response(response.parsed_response)
        puts "Articles found: #{articles.count}"
        articles
      else
        puts "News API Error: #{response.code}"
        handle_error("Error: #{response.code}")
      end
    rescue StandardError => e
      puts "News Rescue Error: #{e.message}"
      handle_error(e.message)
    end
  end

  private

  def self.parse_news_response(data)
    return [] unless data['articles']
    
    data['articles'].first(5).map do |article|
      {
        title: article['title'] || 'Sin título',
        description: article['description'] || 'Sin descripción',
        url: article['url'] || '#',
        image_url: article['urlToImage'],
        source: article['source'] ? article['source']['name'] : 'Desconocido',
        published_at: article['publishedAt'] || Time.current.to_s
      }
    end
  end

  def self.handle_error(message)
    Rails.logger.error("NewsService Error: #{message}")
    sample_news
  end

  def self.sample_news
    [
      {
        title: "🔧 Configura tu API Key",
        description: "Agrega NEWS_API_KEY a tu archivo .env para ver noticias reales",
        url: "https://newsapi.org",
        image_url: nil,
        source: "Sistema",
        published_at: Time.current.to_s
      },
      {
        title: "📰 Noticias del Mundo",
        description: "Una vez configurado, verás las últimas noticias internacionales aquí",
        url: "#",
        image_url: nil,
        source: "Dashboard",
        published_at: Time.current.to_s
      }
    ]
  end
end