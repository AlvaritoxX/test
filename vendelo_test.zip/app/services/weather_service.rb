class WeatherService
  def self.fetch_weather(city = "Santiago", country = "cl")
    api_key = ENV["WEATHER_API_KEY"]
    base_url = "https://api.openweathermap.org/data/2.5/weather"

    # Si no hay API key, usar datos de ejemplo
    unless api_key.present? && api_key != "tu_key_real_o_demo"
      puts "=== Using demo weather data ==="
      return sample_weather(city)
    end

    location = "#{city},#{country}"
    url = "#{base_url}?q=#{location}&appid=#{api_key}&units=metric&lang=es"
    
    begin
      response = HTTParty.get(url)
      puts "=== Weather API Response: #{response.code} ==="
      
      if response.success?
        parse_weather_response(response.parsed_response)
      else
        puts "Weather API Error: #{response.code}"
        handle_error("Error: #{response.code}")
      end
    rescue StandardError => e
      puts "Weather Rescue Error: #{e.message}"
      handle_error(e.message)
    end
  end

  private

  def self.parse_weather_response(data)
    {
      temperature: data['main']['temp'].round(1),
      feels_like: data['main']['feels_like'].round(1),
      humidity: data['main']['humidity'],
      pressure: data['main']['pressure'],
      description: data['weather'].first['description'].capitalize,
      icon: data['weather'].first['icon'],
      city: data['name'],
      country: data['sys']['country'],
      wind_speed: data['wind']['speed'],
      visibility: data['visibility'] / 1000.0,
      sunrise: Time.at(data['sys']['sunrise']).strftime('%H:%M'),
      sunset: Time.at(data['sys']['sunset']).strftime('%H:%M')
    }
  end

  def self.handle_error(message)
    Rails.logger.error("WeatherService Error: #{message}")
    sample_weather
  end

  def self.sample_weather(city = "Santiago")
    {
      temperature: rand(15..30).to_f,
      feels_like: rand(15..30).to_f,
      humidity: rand(40..80),
      pressure: rand(1000..1020),
      description: ["Soleado", "Parcialmente nublado", "Despejado"].sample,
      icon: "01d",
      city: city,
      country: "CL",
      wind_speed: rand(1.0..5.0).round(1),
      visibility: rand(8.0..15.0).round(1),
      sunrise: "06:#{rand(15..45)}",
      sunset: "19:#{rand(15..45)}"
    }
  end
end