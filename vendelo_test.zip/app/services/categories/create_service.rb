# app/services/categories/create_service.rb
module Categories
  class CreateService
    def initialize(category_params)
      @category_params = category_params
    end

    def call
      category = Category.new(@category_params)
      
      if category.save
        { success: true, category: category }
      else
        { success: false, errors: category.errors.full_messages }
      end
    end
  end
end