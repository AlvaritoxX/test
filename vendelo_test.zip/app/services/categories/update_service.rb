# app/services/categories/update_service.rb
module Categories
  class UpdateService
    def initialize(category, category_params)
      @category = category
      @category_params = category_params
    end

    def call
      if @category.update(@category_params)
        { success: true, category: @category }
      else
        { success: false, errors: @category.errors.full_messages }
      end
    end
  end
end