# app/channels/product_channel.rb
class ProductChannel < ApplicationCable::Channel
  def subscribed
    stram_from "product_#{params[:product_id]}"
  end

  def unsubscribed
    puts "🔔 Cliente desuscrito"
  end
end