class ImageOptimizerJob < ApplicationJob
  queue_as :default
  
  def perform(product_id)
    product = Product.find_by(id: product_id)
    return unless product&.image&.attached?
    
    # Solo procesar si la imagen es variable
    return unless product.image.variable?
    
    # Crear variantes optimizadas (sin parámetros strip que pueden causar problemas)
    optimize_product_image(product)
  rescue => e
    Rails.logger.error "Error en ImageOptimizerJob: #{e.message}"
  end
  
  private
  
  def optimize_product_image(product)
    # Variante principal
    product.image.variant(resize_to_limit: [800, 600]).processed
    
    # Miniatura
    product.image.variant(resize_to_fill: [300, 200]).processed
    
    # Pequeña miniatura
    product.image.variant(resize_to_fill: [100, 100]).processed
  end
end